const express = require('express')
const app = express()
const port = 8080

app.use(express.json());

var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "password"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected to db!");
});

app.get('/', (req, res) => {
  res.send('Benvingut a BVote!')
})

app.post('/register', (req, res, next) => {
	var sql = `insert into users.logins(username,password,dni) values("${req.body.username}","${req.body.password}","${req.body.dni}")`;
    con.query(sql, function (err, result) {
    if (err) throw err;
    console.log(`Usuari ${req.body.username} amb password: ${req.body.password} i dni: ${req.body.dni} registrat correctament`)
  });
	res.end(); 
}) 

app.get('/vote', (req, res) => {
 
   
})


app.post('/login', (req, res, next) => {
	var sql = `select username, password from users.logins where username="${req.body.username}" and password="${req.body.password}"`;
    con.query(sql, function (err, result) {
    if (err) throw err;
    //console.log(result)
    console.log(`Usuari ${req.body.username} logejat correctament`)
  });
	res.end(); 
}) 

app.listen(port, () => {
  console.log(`BVote Server listening at http://localhost:${port}`)
})
